package com.motka.workforcemgmt.common.model.enums;

public enum ReferenceType {
    ENTITY, // Represents a Customer/Transporter
    ORDER,
    ENQUIRY
}


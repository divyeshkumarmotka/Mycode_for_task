package com.motka.workforcemgmt.common.model.enums;

public enum Priority {
    LOW,
    MEDIUM,
    HIGH
}


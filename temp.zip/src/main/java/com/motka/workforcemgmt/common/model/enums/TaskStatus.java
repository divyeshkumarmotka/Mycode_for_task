package com.motka.workforcemgmt.common.model.enums;

public enum TaskStatus {
    ASSIGNED,
    STARTED,
    COMPLETED,
    CANCELLED
}


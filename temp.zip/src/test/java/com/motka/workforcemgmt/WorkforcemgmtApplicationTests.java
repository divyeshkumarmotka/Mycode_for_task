package com.motka.workforcemgmt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorkforcemgmtApplicationTests {

	@Test
	void contextLoads() {
	}

}
